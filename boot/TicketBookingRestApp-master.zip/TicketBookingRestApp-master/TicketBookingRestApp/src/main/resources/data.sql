INSERT INTO ticket(passenger_name,booking_date,source_station,dest_station,email) VALUES('Sean','2017/08/14','Pune','Mumbai','sean.s2017@yahoo.com');
INSERT INTO ticket(passenger_name,booking_date,source_station,dest_station,email) VALUES('Raj','2017/08/12','Chennai','Mumbai','raj.s2007@siffy.com');
INSERT INTO ticket(passenger_name,booking_date,source_station,dest_station,email) VALUES('Martin','2017/08/15','Delhi','Mumbai','martin.s2001@xyz.com');
INSERT INTO ticket(passenger_name,booking_date,source_station,dest_station,email) VALUES('John','2017/08/21','Chennai','Mumbai','john.s2011@yahoo.com');
