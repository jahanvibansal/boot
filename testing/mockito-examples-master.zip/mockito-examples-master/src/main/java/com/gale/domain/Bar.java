package com.gale.domain;

public class Bar {
	
	private String name;

	public String getName() {
		return name;
	}
	
	public void wuzzle(Bar bar) {
		//do something fantastic
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
