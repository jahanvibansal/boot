## What You Will Learn during this Step:
- Real world Example with Spring.
- Not very different from previous example.

## Useful Snippets and References
- Download the zip mockito-real-world-example-with-spring.zip and setup this maven project
- For help : use our installation guide - https://github.com/in28minutes/SpringIn28Minutes/blob/master/InstallationGuide-JavaEclipseAndMaven_v2.pdf & https://www.youtube.com/watch?v=DLPjCZ5n_SM &
https://www.youtube.com/watch?v=-xFzftkdycI
