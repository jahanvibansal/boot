## What You Will Learn during this Step:
- Good Unit Tests
-- Basics
--- Readable
--- Fails only when there are real logic failures

## Exercises and References
- FIRST. [https://pragprog.com/magazines/2012-01/unit-tests-are-first](https://pragprog.com/magazines/2012-01/unit-tests-are-first) 
- Patterns - [http://xunitpatterns.com](http://xunitpatterns.com)
- [https://github.com/mockito/mockito/wiki/How-to-write-good-tests](https://github.com/mockito/mockito/wiki/How-to-write-good-tests)
