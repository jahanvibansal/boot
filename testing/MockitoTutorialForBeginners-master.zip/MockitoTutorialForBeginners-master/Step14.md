## What You Will Learn during this Step:
- Some Theory : Why does Mockito not allow stubbing final and private methods?

## Useful Snippets and References
- [https://github.com/mockito/mockito/wiki/Mockito-And-Private-Methods](https://github.com/mockito/mockito/wiki/Mockito-And-Private-Methods)
- [https://github.com/mockito/mockito/wiki/FAQ](https://github.com/mockito/mockito/wiki/FAQ)
