package com.typesafe.service.order.common;

public class AccountNotFoundException extends Exception {
}
