package com.typesafe.service.order.common;

public class ProductNotFoundException extends  Exception {
}
