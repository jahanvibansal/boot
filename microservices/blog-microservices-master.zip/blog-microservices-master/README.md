# blog-microservices

Source code for blogs regarding microservices at http://callistaenterprise.se/blogg/teknik/2015/05/20/blog-series-building-microservices/