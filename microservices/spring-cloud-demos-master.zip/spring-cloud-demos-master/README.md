##Spring Cloud Demos
	springBootVersion = '1.5.7.RELEASE'
	springCloudVersion='Dalston.SR3'
	
	port:
	eureka: 8761
	
	-Xms256M -Xmx512M -XX:MetaspaceSize=128M -XX:MaxMetaspaceSize=256M
	