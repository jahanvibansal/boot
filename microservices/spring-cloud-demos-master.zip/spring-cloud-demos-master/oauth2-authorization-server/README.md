Authorization Server Configuration

https://projects.spring.io/spring-security-oauth/docs/oauth2.html

