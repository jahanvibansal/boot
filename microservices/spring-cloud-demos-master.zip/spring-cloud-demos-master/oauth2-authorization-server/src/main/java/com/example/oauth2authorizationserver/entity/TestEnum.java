package com.example.oauth2authorizationserver.entity;

public enum TestEnum {
    hehe1(1),hehe2(2),hehe3(3);

    private int ff;

    TestEnum(int i) {
        this.ff = i;
    }
}
