package com.gft.academy.selen.constant;


public enum DebtStatus {
    NEW,REJECTED,ACTIVE,RETURNED
}
