package com.gft.academy.selen.constant;

public enum LoanStatus {
    NEW,PENDING,REJECTED,ACTIVE,RETURNED,PENDING_RETURN
}
